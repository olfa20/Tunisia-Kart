const mongoose = require("mongoose");
const uniqueValidator = require("mongoose-unique-validator");

const Schema = mongoose.Schema;

const userSchema = new Schema({
  title: { type: String },
  p1: { type: String },
  p2: { type: String },
  image: { type: String },
  category: { type: mongoose.Types.ObjectId, ref: "Category" },
});

userSchema.plugin(uniqueValidator);

module.exports = mongoose.model("Offer", userSchema);
