const express = require("express");
const { check } = require("express-validator");
const checkAuth = require("../middleware/check-auth");
const categoryController = require("../controllers/category-controller");
const fileUpload = require("../middleware/file-upload");
const router = express.Router();

router.get("/", categoryController.getCategories);
router.get("/:id", categoryController.getCategoryById);
router.get("/name/:name", categoryController.getCategoryByName);

router.use(checkAuth);
router.post(
  "/",
  //[check("name").not().isEmpty()],
  categoryController.createCategory
);

router.patch(
  "/:id",
  fileUpload.single("image"),
  [check("name").not().isEmpty()],
  categoryController.updateCategory
);

router.delete("/:id", categoryController.deleteCategory);
module.exports = router;
