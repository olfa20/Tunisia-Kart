const express = require("express");
const { check } = require("express-validator");
const checkAuth = require("../middleware/check-auth");
const offerController = require("../controllers/offer-controller");
const fileUpload = require("../middleware/file-upload");
const router = express.Router();

router.get("/", offerController.getOffers);
router.get("/home", offerController.getHomeOffers);
router.get("/:id", offerController.getOfferById);
router.get("/name/:name", offerController.getOfferByName);
router.use(checkAuth);
router.post(
  "/",
  fileUpload.single("image"),
  [
    check("title").not().isEmpty(),
    check("p1").not().isEmpty(),
    check("p2").not().isEmpty(),
    check("category").not().isEmpty(),
  ],
  offerController.createOffer
);

router.patch(
  "/:id",
  fileUpload.single("image"),
  [check("title").not().isEmpty()],
  offerController.updateOffer
);

router.delete("/:id", offerController.deleteOffer);
module.exports = router;
