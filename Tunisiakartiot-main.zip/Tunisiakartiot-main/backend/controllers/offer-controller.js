const HttpError = require("../models/http-error");
const Offer = require("../models/offer");
const Category = require("../models/category");
const { validationResult } = require("express-validator");
const mongoose = require("mongoose");

const getOffers = async (req, res, next) => {
  let offers;
  try {
    offers = await Offer.find().populate("category");
  } catch (err) {
    const error = new HttpError(
      err.message || "Fetching offers failed, please try again later",
      500
    );
    return next(error);
  }
  res.json({
    offers: offers.map((offer) => offer.toObject({ getters: true })),
  });
};
const getHomeOffers = async (req, res, next) => {
  let offers;
  let homeOffers = [];
  try {
    offers = await Offer.find().populate("category");
  } catch (err) {
    const error = new HttpError(
      err.message || "Fetching offers failed, please try again later",
      500
    );
    return next(error);
  }
  for (let i = 0; i < 6; i++) {
    if (offers[i]) {
      homeOffers.push(offers[i]);
    }
  }
  res.json({
    offers: homeOffers.map((offer) => offer.toObject({ getters: true })),
  });
};
const getOfferById = async (req, res, next) => {
  const offerId = req.params.id;
  let offer;
  try {
    offer = await Offer.findById(offerId).populate("category");
  } catch (err) {
    const error = new HttpError(
      err.message || "Fetching offer failed, please try again later",
      500
    );
    return next(error);
  }

  if (!offer) {
    const error = new HttpError(
      "Could not find an offer with the provided ID",
      404
    );
    return next(error);
  }

  res.json({ offer: offer.toObject({ getters: true }) });
};

const getOfferByName = async (req, res, next) => {
  let str = req.params.name;
  let offer;
  try {
    offer = await Offer.find({ title: { $regex: str, $options: "i" } });
  } catch (err) {
    const error = new HttpError(
      err.message || "Fetching offer failed, please try again later",
      500
    );
    return next(error);
  }

  if (!offer) {
    const error = new HttpError(
      "Could not find an offer with the provided ID",
      404
    );
    return next(error);
  }
  res.json({ offer: offer });
};
const createOffer = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const err = new HttpError(
      errors.message || "An unknown error occurred!!",
      500
    );
    return next(err);
  }

  const { title, p1, p2, category } = req.body;
  let image;
  if (req.file && !!req.file.path) {
    image = req.file.path;
  }
  let existingOffer;
  try {
    existingOffer = await Offer.findOne({ title: title });
  } catch (err) {
    const error = new HttpError(
      err.message || "Creating Offer failed, please try again later.",
      500
    );
    return next(error);
  }
  if (existingOffer) {
    return next(new HttpError("Offer exists already", 422));
  }

  let createdOffer = new Offer({
    title,
    p1,
    p2,
    category,
    image,
  });

  let existingCategory;
  try {
    existingCategory = await Category.findById(category);
  } catch (err) {
    return next(
      new HttpError(
        err.message || "Fetching category failed, please try again later",
        500
      )
    );
  }
  if (!existingCategory) {
    return next(
      new HttpError("Could not find category with the provided ID.", 404)
    );
  }
  try {
    const sess = await mongoose.startSession();
    sess.startTransaction();
    await createdOffer.save({ session: sess });
    existingCategory.offers.push(createdOffer);
    await existingCategory.save({ session: sess });
    await sess.commitTransaction();
  } catch (err) {
    const error = new HttpError(
      err.message || "Creating offer failed, please try again later.",
      500
    );
    return next(error);
  }
  res.status(201).json({ offer: createdOffer });
};

const updateOffer = async (req, res, next) => {
  const offerId = req.params.id;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const error = new HttpError(
      errors.message || "An unknown error occurred!",
      500
    );
    return next(error);
  }
  let existingOffer;
  try {
    existingOffer = await Offer.findById(offerId);
  } catch (err) {
    const error = new HttpError(
      err.message || "Fetching Offer failed, please try again later",
      500
    );
    return next(error);
  }
  if (!existingOffer) {
    return next(
      new HttpError("Could not find Offer with the provided Id", 404)
    );
  }

  const { title, p1, p2, category } = req.body;
  if (title) {
    existingOffer.title = title;
  }
  if (p1) {
    existingOffer.p1 = p1;
  }
  if (p2) {
    existingOffer.p2 = p2;
  }
  if (category) {
    existingOffer.category = category;
  }

  if (req.file && !!req.file.path) {
    existingOffer.image = req.file.path;
  }

  try {
    await existingOffer.save();
  } catch (err) {
    const error = new HttpError(
      err.message || "Updating offer failed, please try again later",
      500
    );
    return next(error);
  }
  res.status(201).json({ updatedOffer: existingOffer });
};

const deleteOffer = async (req, res, next) => {
  const offerId = req.params.id;
  let offer;
  try {
    offer = await Offer.findById(offerId).populate("category");
  } catch (err) {
    const error = new HttpError(
      "Something went wrong, could not delete offer..",
      500
    );
    return next(error);
  }

  if (!offer) {
    const error = new HttpError("Could not find offer for this id.", 404);
    return next(error);
  }
  try {
    const sess = await mongoose.startSession();
    sess.startTransaction();
    await offer.remove({ session: sess });
    offer.category.offers.pull(offer);
    await offer.category.save({ session: sess });
    await sess.commitTransaction();
  } catch (err) {
    const error = new HttpError(
      "Something went wrong, could not delete offer.",
      500
    );
  }
  res.status(200).json({ message: "Deleted offer." });
};

exports.getHomeOffers = getHomeOffers;
exports.getOfferByName = getOfferByName;
exports.deleteOffer = deleteOffer;
exports.getOffers = getOffers;
exports.getOfferById = getOfferById;
exports.createOffer = createOffer;
exports.updateOffer = updateOffer;
