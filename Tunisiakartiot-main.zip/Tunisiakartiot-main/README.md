# Tunisiakartiot
Pour lancer le projet web, vous devez suivre ces etapes :
- ouvrir le dossier Backend.
- lancer dans cmd npm i
- lancer dans cmd npm start
- ouvrir le dossier frontend.
- lancer dans cmd npm i
- lancer dans cmd npm start

Pour la partie IOT , vous dever realiser le montage suivant:
![My Image](IOT/iot.PNG)

coller le code tunisiakart.ino dans arduino.

lancer le code.
