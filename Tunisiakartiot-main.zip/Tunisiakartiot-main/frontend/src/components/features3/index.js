import React from "react";

import "./style.css";

const Features3 = ({ offer }) => {
  return (
    <div className="wpo-section-style-3">
      <div className="container">
        <div className="row">
          <div className="col-lg-4 col-md-9 col-sm-12 col-d c-pd">
            {offer.image ? (
              <img
                src={`${process.env.REACT_APP_BACKEND_URL}` + offer.image}
                alt={offer.title}
              />
            ) : (
              ""
            )}

            {/* <div className="section-wrap">
                            <div className="wpo-section-item-2">
                                <div className="wpo-section-icon">
                                    <i className="fi flaticon-ship"></i>
                                </div>
                                <div className="wpo-section-content">
                                    <p><Link to="/ocean">Ocean Freight</Link></p>
                                    <span>There are many variations of passages of Lorem Ipsum</span>
                                </div>
                            </div>
                            <div className="wpo-section-item-2">
                                <div className="wpo-section-icon">
                                    <i className="fi flaticon-truck"></i>
                                </div>
                                <div className="wpo-section-content">
                                    <p><Link to="/road">Road Freight</Link></p>
                                    <span>There are many variations of passages of Lorem Ipsum</span>
                                </div>
                            </div>
                            <div className="wpo-section-item-2">
                                <div className="wpo-section-icon">
                                    <i className="fi flaticon-plane"></i>
                                </div>
                                <div className="wpo-section-content">
                                    <p><Link to="/freight">Air Freight</Link></p>
                                    <span>There are many variations of passages of Lorem Ipsum</span>
                                </div>
                            </div>
                        </div> */}
          </div>
          <div className="col-lg-8 col-md-12 col-sm-12">
            <div className="tr-wrap">
              <div className="t-text">
                <h2>{offer.title}</h2>
                <p>{offer.p1}</p>
              </div>
              <div className="t-text">
                <p>{offer.p2}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Features3;
