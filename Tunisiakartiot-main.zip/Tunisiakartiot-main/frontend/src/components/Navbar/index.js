import React, { useContext } from "react";
import Header from "../header";
import { AuthContext } from "./../../shared/authContext";

export default function Navbar() {
  const auth = useContext(AuthContext);
  const [scroll, setScroll] = React.useState(0);

  const handleScroll = () => setScroll(document.documentElement.scrollTop);

  React.useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  let className;
  if (auth.isLoggedIn) {
    className = "fixed-navbar animated fadeInDown active";
  } else {
    className =
      scroll > 80 ? "fixed-navbar animated fadeInDown active" : "fixed-navbar";
  }
  return (
    <div className={className}>
      <Header />
    </div>
  );
}
