import React, { useContext, useState } from "react";
import { Link, useHistory } from "react-router-dom";
import MobileMenu from "../../components/MobileMenu";
import logo from "../../images/logo/logo.png";
import { AuthContext } from "./../../shared/authContext";

import "./style.css";

const Header = () => {
  const auth = useContext(AuthContext);
  const history = useHistory();
  const [search, setSearch] = useState("");
  const handleChange = (event) => {
    setSearch(event.currentTarget.value);
  };
  const searchA = () => {
    history.push("/offers/" + search);
    setSearch("");
  };
  const myfn = () => {
    auth.logout();
  };
  return (
    <header>
      <div className="header-top-1">
        <div className="container">
          <div className="row">
            <div className="col-md-9 col-sm-12 col-12">
              <ul className="d-flex account_login-area">
                <li>
                  <i className="fa fa-clock-o" aria-hidden="true"></i>Monday -
                  Friday : 8.00 am - 17.00 pm
                </li>
                <li>
                  <i className="fa fa-map-marker"></i>Route Principale N°1 4011,
                  H. SOUSSE SOUSSE Tunisie
                </li>
              </ul>
            </div>
            <div className="col-lg-3 col-md-3 col-sm-12">
              <div className="btn-style">
                <Link to="/contact">Contact Us</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="header-style-1">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-10 col-sm-10 col-8 col-t">
              <div className="logo">
                <Link to="/">
                  <img src={logo} alt="" />
                </Link>
              </div>
            </div>
            <div className="col-lg-8 d-none d-lg-block col-m">
              <div className="main-menu">
                <nav className="nav_mobile_menu">
                  <ul>
                    <li className="active">
                      <Link to="/">Home</Link>
                    </li>
                    <li>
                      <Link to="/about">About Us</Link>
                    </li>
                    <li>
                      <Link to="/offers">Offers</Link>
                    </li>

                    <li>
                      <Link to="/contact">Contact</Link>
                    </li>
                    {auth.isLoggedIn ? (
                      <li>
                        <Link to="/" onClick={myfn}>
                          LOGOUT
                        </Link>
                      </li>
                    ) : (
                      ""
                    )}
                  </ul>
                </nav>
              </div>
            </div>
            <div className="col-lg-1 col-md-1 col-sm-1 col-2 search">
              <ul>
                <li>
                  <Link to="#">
                    <i className="fa fa-search"></i>
                  </Link>
                  <ul>
                    <li>
                      <form onSubmit={searchA}>
                        <input
                          type="text"
                          placeholder="search here.."
                          onChange={handleChange}
                          name="search"
                          value={search}
                        />
                        <button type="submit" onClick={searchA}>
                          <i className="fa fa-search"></i>
                        </button>
                      </form>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
            <div className="col-md-1 col-sm-1 col-2">
              <MobileMenu />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
