import React from "react";
import { Link } from "react-router-dom";
import logo from "../../images/logo/logo.png";

import "./style.css";

const FooterSection = () => {
  return (
    <div className="wpo-footer-area">
      <div className="wpo-footer-top">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-6 col-sm-6 footer-t">
              <div className="wpo-footer-logo">
                <img src={logo} alt="" />
              </div>
              <p>
                There are many variations of Lorem passages of Lorem Ipsum
                available, but the majority
              </p>
              <p>By injected humour, or randomised words</p>
              <div className="social">
                <ul className="d-flex">
                  <li>
                    <Link to="/">
                      <i className="fa fa-facebook" aria-hidden="true"></i>
                    </Link>
                  </li>
                  <li>
                    <Link to="/">
                      <i className="fa fa-twitter" aria-hidden="true"></i>
                    </Link>
                  </li>
                  <li>
                    <Link to="/">
                      <i className="fa fa-linkedin" aria-hidden="true"></i>
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
            <div className="col-lg-3 col-md-6 col-sm-6 footer-t"></div>

            <div className="col-lg-3 col-sm-6 col-12">
              <div className="footer-link">
                <h3>Quick Link</h3>
                <ul>
                  <li>
                    <Link to="/about">About Us</Link>
                  </li>
                  <li>
                    <Link to="/offers">Offers</Link>
                  </li>
                  <li>
                    <Link to="/contact">Contact</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="wpo-footer-bottom">
        <div className="container">
          <div className="wpo-footer-bottom-content">
            <div className="row">
              <div className="col-12">
                <span>© Copyrights 2020. All Rights Reserved.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FooterSection;
