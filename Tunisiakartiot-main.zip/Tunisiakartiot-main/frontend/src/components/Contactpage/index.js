import React from "react";
import ContactForm2 from "../CommentForm2";

import "./style.css";

const Contactpage = () => {
  return (
    <div className="contact-page-area section-padding">
      <div className="container">
        <div className="row">
          <div className="col-lg-5 col-md-12">
            <div className="contact-page-item">
              <h2>Our Contacts</h2>
              <p>
                Contrary to popular belief, Lorem Ipsum is not simply random
                text. It has roots in a piece of classNameical Latin literature
                from 45 BC, making it over 2000 years old.
              </p>
              <div className="adress">
                <h3>Address</h3>
                <span>Route Principale N°1 4011, H. SOUSSE SOUSSE Tunisie</span>
              </div>
              <div className="phone">
                <h3>Phone</h3>
                <span>+216 23 123 123</span>
                <span>+216 23 123 123</span>
              </div>
              <div className="email">
                <h3>Email</h3>
                <span>sample@gmail.com</span>
              </div>
            </div>
          </div>
          <div className="col-lg-7 col-md-12">
            <div className="contact-area contact-area-2 contact-area-3">
              <h2>Quick Contact Form</h2>
              <ContactForm2 />
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col col-xs-12">
            <div className="contact-map">
              <iframe
                title="db"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25873.463611424202!2d10.577135400000062!3d35.84451723000146!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12fd8a6ac0dd6b73%3A0x3a7c2268934541aa!2sInstitut%20Sup%C3%A9rieur%20d&#39;Informatique%20et%20des%20Technologies%20de%20Communication!5e0!3m2!1sfr!2stn!4v1668947527124!5m2!1sfr!2stn"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contactpage;
