import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./style.css";
const ServiceArea3 = () => {
  const [offers, setOffers] = useState([]);
  useEffect(() => {
    const sendRequest = async () => {
      try {
        //fetch
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}offer/home`
        );
        const responseData = await response.json();
        if (!response.ok) {
          throw new Error(responseData.message);
        }
        setOffers(responseData.offers);
      } catch (err) {
        console.log(err);
      }
    };

    sendRequest();
  }, []);

  return (
    <div className="service-style-3" style={{ marginBottom: "100px" }}>
      <div className="container">
        <div className="col-l2">
          <div className="wpo-section-title text-center">
            <h2>Our Offers</h2>
          </div>
        </div>
        <div className="row">
          {offers.map((offer, index) => (
            <div className="col-lg-4 col-md-6 col-sm-12" key={index}>
              <div className="wpo-service-item">
                <div className="wpo-service-icon">
                  <i
                    class="fa fa-subway"
                    aria-hidden="true"
                    style={{ fontSize: "30px" }}
                  ></i>
                </div>
                <Link to={"/offerDetails/" + offer.id}>
                  <div
                    className="service-text"
                    style={{ paddingTop: "50px", paddingBottom: "50px" }}
                  >
                    <h3>{offer.title}</h3>
                    <p>{offer.category.name} </p>
                  </div>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServiceArea3;
