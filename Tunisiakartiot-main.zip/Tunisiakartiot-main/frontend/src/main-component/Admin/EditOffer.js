import React, { useContext, useEffect, useState } from "react";

// components
import Navbar from "../../components/Navbar";

import FooterSection from "../../components/Footer";
import { Link, useHistory, useParams } from "react-router-dom";
import "./style.css";
import { AuthContext } from "./../../shared/authContext";

const EditOffer = () => {
  const auth = useContext(AuthContext);
  const history = useHistory();
  const params = useParams();
  const offerID = params.id;
  const [error, setError] = useState(false);
  const [message, setMessage] = useState("");
  const [oldImg, setOldImg] = useState(null);
  const [offer, setOffer] = useState({
    title: "",
    p1: "",
    p2: "",
    category: "",
    image: null,
  });
  useEffect(() => {
    const sendRequest = async () => {
      try {
        //fetch
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}offer/` + offerID
        );
        const responseData = await response.json();
        if (!response.ok) {
          throw new Error(responseData.message);
        }
        setOffer(responseData.offer);
        setOldImg(
          `${process.env.REACT_APP_BACKEND_URL}` + responseData.offer.image
        );
      } catch (err) {
        console.log(err);
      }
    };

    sendRequest();
  }, [offerID]);
  const handleChange = (event) => {
    setOffer({
      ...offer,
      [event.currentTarget.name]: event.currentTarget.value,
    });
  };
  const submitHandler = async (event) => {
    event.preventDefault();
    if (!offer.title) {
      setError(true);
      setMessage("Title is required");
    } else if (!offer.p1) {
      setError(true);
      setMessage("First Paragraph is required");
    } else {
      const formData = new FormData();
      formData.append("title", offer.title);
      formData.append("p1", offer.p1);
      formData.append("p2", offer.p2);
      formData.append("image", offer.image);
      try {
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}offer/` + offerID,
          {
            method: "PATCH",
            headers: {
              Authorization: "Bearer " + auth.token,
            },
            body: formData,
          }
        );
        const responseData = await response.json();

        if (!response.ok) {
          throw new Error(responseData.message);
        }
        history.push("/admin/offers");
      } catch (err) {
        setError(true);
        setMessage(err.message);
      }
    }
  };
  const pickedHandler = (event) => {
    let pickedFile;
    if (event.currentTarget.files && event.currentTarget.files.length === 1) {
      pickedFile = event.currentTarget.files[0];
      setOffer({
        ...offer,
        [event.currentTarget.name]: pickedFile,
      });
      setOldImg(URL.createObjectURL(event.currentTarget.files[0]));
    }
  };
  return (
    <div>
      <Navbar />
      <div className="Freight-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-12">
              <div className="row">
                <div className="col-lg-12 col-md-6">
                  <div className="catagory-item">
                    <div className="widget-title">
                      <h3 className="text-left">
                        <Link to="/admin">Dashboard</Link>
                      </h3>
                    </div>
                    <div className="category-section">
                      <ul>
                        <li>
                          <Link to="/admin/categories">Categories</Link>
                        </li>
                        <li>
                          <Link to="/admin/categories/add">Add Category</Link>
                        </li>
                        <li>
                          <Link to="/admin/Offers">Offers</Link>
                        </li>
                        <li>
                          <Link to="/admin/offers/add">Add Offer</Link>
                        </li>
                        <li>
                          <Link to="/admin/editpass">Change Password</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-9">
              <div className="contact-area contact-area-2 contact-area-3">
                <h2>Edit Category</h2>
                {error ? <p style={{ color: "red" }}>{message}</p> : ""}

                <form onSubmit={submitHandler}>
                  <div className="contact-form form-style row">
                    <div className="col-8">
                      <input
                        type="name"
                        value={offer.title}
                        onChange={handleChange}
                        placeholder="Title *"
                        name="title"
                        style={{ color: "#000" }}
                      />
                    </div>
                    <div className="col-8">
                      <input
                        type="text"
                        value={offer.category.name}
                        placeholder="Category *"
                        name="category"
                        style={{ color: "gray" }}
                        disabled
                      />
                    </div>
                    <div className="col-8">
                      <textarea
                        type="text"
                        value={offer.p1}
                        onChange={handleChange}
                        placeholder="First Paragraph *"
                        name="p1"
                        style={{ color: "#000" }}
                      ></textarea>
                    </div>
                    <div className="col-8">
                      <textarea
                        type="text"
                        value={offer.p2}
                        onChange={handleChange}
                        placeholder="Second Paragraph *"
                        name="p2"
                        style={{ color: "#000" }}
                      ></textarea>
                    </div>
                    <div className="col-8">
                      {oldImg ? (
                        <img
                          src={oldImg}
                          alt={offer.title}
                          style={{ width: "100px" }}
                        />
                      ) : (
                        ""
                      )}
                    </div>
                    <div className="col-8">
                      <input
                        type="file"
                        onChange={pickedHandler}
                        name="image"
                        style={{ color: "#000" }}
                      />
                    </div>
                    <div className="col-12">
                      <button type="submit" className="theme-btn">
                        Save
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <FooterSection />
    </div>
  );
};

export default EditOffer;
