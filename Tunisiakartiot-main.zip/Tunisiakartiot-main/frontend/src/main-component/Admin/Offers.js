import React, { useContext, useEffect, useState } from "react";

// components
import Navbar from "../../components/Navbar";

import FooterSection from "../../components/Footer";
import { Link } from "react-router-dom";
import "./style.css";
import { AuthContext } from "./../../shared/authContext";

const Offers = () => {
  const auth = useContext(AuthContext);
  const [offers, setOffers] = useState([]);
  const [search, setSearch] = useState("");
  useEffect(() => {
    const sendRequest = async () => {
      try {
        //fetch
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}offer`
        );
        const responseData = await response.json();
        if (!response.ok) {
          throw new Error(responseData.message);
        }
        setOffers(responseData.offers);
      } catch (err) {
        console.log(err);
      }
    };

    if (search.length === 0) {
      sendRequest();
    } else {
      searchA();
    }
  }, [search]);

  const handleDeleteClick = async (offID) => {
    setOffers(offers.filter((d) => d.id !== offID));
    try {
      const response = await fetch(
        `${process.env.REACT_APP_BACKEND_URL}offer/` + offID,
        {
          method: "DELETE",
          headers: {
            Authorization: "Bearer " + auth.token,
          },
        }
      );
      const responseData = await response.json();

      if (!response.ok) {
        throw new Error(responseData.message);
      }
    } catch (err) {}
  };
  const handleChange = (event) => {
    setSearch(event.currentTarget.value);
  };
  const searchA = async () => {
    try {
      //fetch
      const response = await fetch(
        `${process.env.REACT_APP_BACKEND_URL}offer/name/` + search
      );
      const responseData = await response.json();
      if (!response.ok) {
        throw new Error(responseData.message);
      }
      setOffers(responseData.offer);
    } catch (err) {
      console.log(err.message);
    }
  };
  return (
    <div>
      <Navbar />
      <div className="Freight-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-12">
              <div className="row">
                <div className="col-lg-12 col-md-6">
                  <div className="catagory-item">
                    <div className="widget-title">
                      <h3 className="text-left">
                        <Link to="/admin">Dashboard</Link>
                      </h3>
                    </div>
                    <div className="category-section">
                      <ul>
                        <li>
                          <Link to="/admin/categories">Categories</Link>
                        </li>
                        <li>
                          <Link to="/admin/categories/add">Add Category</Link>
                        </li>
                        <li>
                          <Link to="/admin/Offers">Offers</Link>
                        </li>
                        <li>
                          <Link to="/admin/offers/add">Add Offer</Link>
                        </li>
                        <li>
                          <Link to="/admin/editpass">Change Password</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-lg-9">
              <div className="col-lg-12 text-right">
                <input
                  className="amineInput"
                  type="text"
                  onChange={handleChange}
                  name="search"
                  value={search}
                  placeholder="Search Here"
                />
              </div>
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Category</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                  </tr>
                </thead>
                <tbody>
                  {offers.map((off, index) => (
                    <tr>
                      <th scope="row">{index}</th>
                      <td>{off.title}</td>
                      <td>{off.category.name}</td>
                      <td>
                        <Link
                          to={"/admin/offers/edit/" + off.id}
                          style={{ fontSize: "25px", color: "blue" }}
                        >
                          <i
                            class="fa fa-pencil-square-o"
                            aria-hidden="true"
                          ></i>
                        </Link>
                      </td>
                      <td>
                        <Link
                          style={{ fontSize: "25px", color: "red" }}
                          to={"#"}
                          onClick={() => handleDeleteClick(off.id)}
                        >
                          <i class="fa fa-trash" aria-hidden="true"></i>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <FooterSection />
    </div>
  );
};

export default Offers;
