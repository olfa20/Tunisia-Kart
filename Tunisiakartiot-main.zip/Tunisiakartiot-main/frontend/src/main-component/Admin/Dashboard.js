import React from "react";

// components
import Navbar from "../../components/Navbar";

import FooterSection from "../../components/Footer";
import { Link } from "react-router-dom";
import "./style.css";
const Dashboard = () => {
  return (
    <div>
      <Navbar />
      <div className="Freight-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-12">
              <div className="row">
                <div className="col-lg-12 col-md-6">
                  <div className="catagory-item">
                    <div className="widget-title">
                      <h3 className="text-left">
                        <Link to="/admin">Dashboard</Link>
                      </h3>
                    </div>
                    <div className="category-section">
                      <ul>
                        <li>
                          <Link to="/admin/categories">Categories</Link>
                        </li>
                        <li>
                          <Link to="/admin/categories/add">Add Category</Link>
                        </li>
                        <li>
                          <Link to="/admin/Offers">Offers</Link>
                        </li>
                        <li>
                          <Link to="/admin/offers/add">Add Offer</Link>
                        </li>
                        <li>
                          <Link to="/admin/editpass">Change Password</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-9"></div>
          </div>
        </div>
      </div>
      <FooterSection />
    </div>
  );
};

export default Dashboard;
