import React, { useContext, useEffect, useState } from "react";

// components
import Navbar from "../../components/Navbar";

import FooterSection from "../../components/Footer";
import { Link, useHistory, useParams } from "react-router-dom";
import "./style.css";
import { AuthContext } from "./../../shared/authContext";

const EditCategory = () => {
  const auth = useContext(AuthContext);
  const params = useParams();
  const catID = params.id;
  const [error, setError] = useState(false);
  const [message, setMessage] = useState("");
  const [formdata, setFormData] = useState({
    name: "",
  });

  const history = useHistory();
  useEffect(() => {
    const sendRequest = async () => {
      try {
        //fetch
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}category/` + catID
        );

        const responseData = await response.json();
        if (!response.ok) {
          throw new Error(responseData.message);
        }
        setFormData(responseData.category);
      } catch (err) {
        console.log(err);
      }
    };

    sendRequest();
  }, []);
  const handleChange = (event) => {
    setFormData({
      ...formdata,
      [event.currentTarget.name]: event.currentTarget.value,
    });
  };
  const submitHandler = async (event) => {
    event.preventDefault();
    if (!formdata.name) {
      setError(true);
      setMessage("Name is required");
    } else {
      try {
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}category/` + catID,
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + auth.token,
            },
            body: JSON.stringify({
              name: formdata.name,
            }),
          }
        );
        const responseData = await response.json();

        if (!response.ok) {
          throw new Error(responseData.message);
        }
        history.push("/admin/categories");
      } catch (err) {
        setError(true);
        setMessage(err.message);
      }
    }
  };

  return (
    <div>
      <Navbar />
      <div className="Freight-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-12">
              <div className="row">
                <div className="col-lg-12 col-md-6">
                  <div className="catagory-item">
                    <div className="widget-title">
                      <h3 className="text-left">
                        <Link to="/admin">Dashboard</Link>
                      </h3>
                    </div>
                    <div className="category-section">
                      <ul>
                        <li>
                          <Link to="/admin/categories">Categories</Link>
                        </li>
                        <li>
                          <Link to="/admin/categories/add">Add Category</Link>
                        </li>
                        <li>
                          <Link to="/admin/Offers">Offers</Link>
                        </li>
                        <li>
                          <Link to="/admin/offers/add">Add Offer</Link>
                        </li>
                        <li>
                          <Link to="/admin/editpass">Change Password</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-9">
              <div className="contact-area contact-area-2 contact-area-3">
                <h2>Edit Category</h2>
                {error ? <p style={{ color: "red" }}>{message}</p> : ""}

                <form onSubmit={submitHandler}>
                  <div className="contact-form form-style row">
                    <div className="col-8">
                      <input
                        type="text"
                        value={formdata.name}
                        onChange={handleChange}
                        placeholder="Category Name*"
                        name="name"
                        style={{ color: "#000" }}
                      />
                    </div>
                    <div className="col-12">
                      <button type="submit" className="theme-btn">
                        Save
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <FooterSection />
    </div>
  );
};

export default EditCategory;
