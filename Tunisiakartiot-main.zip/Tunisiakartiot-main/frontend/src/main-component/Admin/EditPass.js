import React, { useContext, useEffect, useState } from "react";

// components
import Navbar from "../../components/Navbar";

import FooterSection from "../../components/Footer";
import { Link, useHistory, useParams } from "react-router-dom";
import "./style.css";
import { AuthContext } from "./../../shared/authContext";

const EditPass = () => {
  const auth = useContext(AuthContext);
  const [error, setError] = useState(false);
  const [message, setMessage] = useState("");
  const [formdata, setFormData] = useState({
    currentPassword: "",
    newPassword: "",
  });

  const history = useHistory();

  const handleChange = (event) => {
    setFormData({
      ...formdata,
      [event.currentTarget.name]: event.currentTarget.value,
    });
  };
  const submitHandler = async (event) => {
    event.preventDefault();
    if (!formdata.currentPassword) {
      setError(true);
      setMessage("Current Password is required");
    } else if (!formdata.newPassword) {
      setError(true);
      setMessage("New Password is required");
    } else {
      try {
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}user/editpass/` + auth.userId,
          {
            method: "PATCH",
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + auth.token,
            },
            body: JSON.stringify({
              currentPassword: formdata.currentPassword,
              newPassword: formdata.newPassword,
            }),
          }
        );
        const responseData = await response.json();

        if (!response.ok) {
          throw new Error(responseData.message);
        }
        history.push("/admin");
      } catch (err) {
        setError(true);
        setMessage(err.message);
      }
    }
  };

  return (
    <div>
      <Navbar />
      <div className="Freight-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-12">
              <div className="row">
                <div className="col-lg-12 col-md-6">
                  <div className="catagory-item">
                    <div className="widget-title">
                      <h3 className="text-left">
                        <Link to="/admin">Dashboard</Link>
                      </h3>
                    </div>
                    <div className="category-section">
                      <ul>
                        <li>
                          <Link to="/admin/categories">Categories</Link>
                        </li>
                        <li>
                          <Link to="/admin/categories/add">Add Category</Link>
                        </li>
                        <li>
                          <Link to="/admin/Offers">Offers</Link>
                        </li>
                        <li>
                          <Link to="/admin/offers/add">Add Offer</Link>
                        </li>
                        <li>
                          <Link to="/admin/editpass">Change Password</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-9">
              <div className="contact-area contact-area-2 contact-area-3">
                <h2>Change Password</h2>
                {error ? <p style={{ color: "red" }}>{message}</p> : ""}

                <form onSubmit={submitHandler}>
                  <div className="contact-form form-style row">
                    <div className="col-8">
                      <input
                        type="password"
                        value={formdata.currentPassword}
                        onChange={handleChange}
                        placeholder="Current Password*"
                        name="currentPassword"
                        style={{ color: "#000" }}
                      />
                    </div>
                    <div className="col-8">
                      <input
                        type="password"
                        value={formdata.newPassword}
                        onChange={handleChange}
                        placeholder="New Password*"
                        name="newPassword"
                        style={{ color: "#000" }}
                      />
                    </div>
                    <div className="col-12">
                      <button type="submit" className="theme-btn">
                        Save
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <FooterSection />
    </div>
  );
};

export default EditPass;
