import React, { useEffect, useState } from "react";
import "./style.css";
// components
import Navbar from "../../components/Navbar";
import Breadcumb from "../../components/breadcumb";

import FooterSection from "../../components/Footer";
import { Link, useParams } from "react-router-dom";

const Offers = () => {
  const [offers, setOffers] = useState([]);
  const [search, setSearch] = useState("");
  const params = useParams();
  const searchkey = params.searchkey;
  const [mysr, setMysr] = useState(searchkey);
  const searchA = async () => {
    try {
      //fetch
      const response = await fetch(
        `${process.env.REACT_APP_BACKEND_URL}offer/name/` + search
      );
      const responseData = await response.json();
      if (!response.ok) {
        throw new Error(responseData.message);
      }
      setOffers(responseData.offer);
    } catch (err) {
      console.log(err.message);
    }
  };
  const handleChange = (event) => {
    setSearch(event.currentTarget.value);
  };
  useEffect(() => {
    const sendRequest = async () => {
      try {
        //fetch
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}offer`
        );
        const responseData = await response.json();
        if (!response.ok) {
          throw new Error(responseData.message);
        }
        setOffers(responseData.offers);
      } catch (err) {
        console.log(err);
      }
    };

    if (mysr) {
      setSearch(mysr);
      searchA();
      setMysr(null);
    } else if (search.length === 0) {
      sendRequest();
    } else {
      searchA();
    }
  }, [search]);
  return (
    <div>
      <Navbar />
      <Breadcumb bdtitle={"All Offers"} bdsub={"Offers"} />

      <div className="service-style-3" style={{ marginBottom: "100px" }}>
        <div className="container">
          <div className="col-l2">
            <div className="wpo-section-title text-center">
              <h2>Our Offers</h2>
            </div>
          </div>
          <div className="col-lg-12 text-right">
            <input
              className="amineInput"
              type="text"
              onChange={handleChange}
              name="search"
              value={search}
              placeholder="Search Here"
            />
          </div>
          <div className="row">
            {offers.map((offer, index) => (
              <div className="col-lg-4 col-md-6 col-sm-12" key={index}>
                <div className="wpo-service-item">
                  <div className="wpo-service-icon">
                    <i
                      class="fa fa-subway"
                      aria-hidden="true"
                      style={{ fontSize: "30px" }}
                    ></i>
                  </div>
                  <Link to={"/offerDetails/" + offer._id}>
                    <div
                      className="service-text"
                      style={{ paddingTop: "50px", paddingBottom: "50px" }}
                    >
                      <h3>{offer.title}</h3>
                      <p>{offer.category.name} </p>
                    </div>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <FooterSection />
    </div>
  );
};

export default Offers;
