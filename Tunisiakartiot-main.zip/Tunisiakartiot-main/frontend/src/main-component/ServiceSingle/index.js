import React, { useEffect, useState } from "react";

// components
import Navbar from "../../components/Navbar";
import Breadcumb from "../../components/breadcumb";
import Features3 from "../../components/features3";
import FooterSection from "../../components/Footer";
import { useParams } from "react-router-dom";

const ServiceSingle = () => {
  const params = useParams();
  const offerID = params.id;
  const [offer, setOffer] = useState({
    title: "",
    p1: "",
    p2: "",
    category: "",
    image: null,
  });
  useEffect(() => {
    const sendRequest = async () => {
      try {
        //fetch
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}offer/` + offerID
        );
        console.log(`${process.env.REACT_APP_BACKEND_URL}offer/`);
        const responseData = await response.json();
        if (!response.ok) {
          throw new Error(responseData.message);
        }
        setOffer(responseData.offer);
      } catch (err) {
        console.log(err);
      }
    };

    sendRequest();
  }, [offerID]);
  return (
    <div>
      <Navbar />
      <Breadcumb bdtitle={offer.title} bdsub={"Offers"} bdlink={"/offers"} />
      <Features3 offer={offer} />

      <FooterSection />
    </div>
  );
};

export default ServiceSingle;
