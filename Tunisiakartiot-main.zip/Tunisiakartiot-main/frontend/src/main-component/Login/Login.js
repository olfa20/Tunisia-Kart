import React, { useContext, useState } from "react";

// components
import Navbar from "../../components/Navbar";
import Breadcumb from "../../components/breadcumb";
import { AuthContext } from "./../../shared/authContext";
import FooterSection from "../../components/Footer";
import "./style.css";
import { useHistory } from "react-router-dom";

const Login = () => {
  const auth = useContext(AuthContext);
  const history = useHistory();
  const [formdata, setFormdata] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState(false);
  const [message, setMessage] = useState("");
  const submitHandler = async (event) => {
    event.preventDefault();
    setError(false);
    if (!formdata.email) {
      setError(true);
      setMessage("Email is required");
    } else if (!formdata.password) {
      setError(true);
      setMessage("Password is required");
    } else {
      try {
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}user/login`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              email: formdata.email,
              password: formdata.password,
            }),
          }
        );
        const responseData = await response.json();
        if (!response.ok) {
          setError(true);
          setMessage(responseData.message);
          throw new Error(responseData.message);
        }
        auth.login(responseData.userId, responseData.token);
        history.push("/admin");
      } catch (err) {
        setError(true);
        setMessage(err.message);
      }
    }
  };
  const handleChange = (event) => {
    setFormdata({
      ...formdata,
      [event.currentTarget.name]: event.currentTarget.value,
    });
  };
  return (
    <div>
      <Navbar />
      <Breadcumb bdtitle={"LOGIN"} bdsub={"Login"} />
      <div className="contact-page-area section-padding">
        <div className="container">
          <div className="row">
            <div className="col-lg-5 col-md-12"></div>
            <div className="col-lg-7 col-md-12">
              <div className="contact-area contact-area-2 contact-area-3">
                <h2>LOGIN</h2>
                {error ? <p style={{ color: "red" }}>{message}</p> : ""}

                <form onSubmit={submitHandler}>
                  <div className="contact-form form-style row">
                    <div className="col-8">
                      <input
                        type="email"
                        value={formdata.email}
                        onChange={handleChange}
                        placeholder="Your Email*"
                        name="email"
                        style={{ color: "#000" }}
                      />
                    </div>
                    <div className="col-8">
                      <input
                        type="password"
                        placeholder="Your Password*"
                        onChange={handleChange}
                        value={formdata.password}
                        name="password"
                        style={{ color: "#000" }}
                      />
                    </div>

                    <div className="col-12">
                      <button type="submit" className="theme-btn">
                        Login
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <FooterSection />
    </div>
  );
};

export default Login;
