import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

import Homepage from "../HomePage3";
import Aboutpage from "../AboutPage";
import ServiceSingle from "../ServiceSingle";
import ContactPage from "../ContactPage";
import Offers from "../Offers/Offers";
import Login from "../Login/Login";
import { AuthContext } from "./../../shared/authContext";
import { useAuth } from "./../../shared/authHook";
import Dashboard from "../Admin/Dashboard";
import Categories from "../Admin/Categories";
import ADOffers from "../Admin/Offers";
import EditCategory from "../Admin/EditCategory";
import AddCategory from "../Admin/AddCategory";
import EditOffer from "../Admin/EditOffer";
import AddOffer from "../Admin/AddOffer";
import EditPass from "../Admin/EditPass";

const AllRoute = () => {
  const { token, login, logout, userId } = useAuth();

  let routes;
  if (token) {
    routes = (
      <Router>
        <Switch>
          <Route exact path="/" component={Homepage} />
          <Route path="/about" exact component={Aboutpage} />
          <Route path="/offers" exact component={Offers} />
          <Route path="/offers/:searchkey" exact component={Offers} />
          <Route path="/offerDetails/:id" exact component={ServiceSingle} />
          <Route path="/contact" exact component={ContactPage} />
          <Route path="/admin" exact component={Dashboard} />
          <Route path="/admin/categories" exact component={Categories} />
          <Route
            path="/admin/categories/edit/:id"
            exact
            component={EditCategory}
          />
          <Route path="/admin/categories/add/" exact component={AddCategory} />
          <Route path="/admin/offers" exact component={ADOffers} />
          <Route path="/admin/offers/edit/:id" exact component={EditOffer} />
          <Route path="/admin/offers/add" exact component={AddOffer} />
          <Route path="/admin/editpass" exact component={EditPass} />
        </Switch>
      </Router>
    );
  } else {
    routes = (
      <Router>
        <Switch>
          <Route exact path="/" component={Homepage} />
          <Route path="/about" exact component={Aboutpage} />
          <Route path="/offers" exact component={Offers} />
          <Route path="/offers/:searchkey" exact component={Offers} />
          <Route path="/offerDetails/:id" exact component={ServiceSingle} />
          <Route path="/contact" exact component={ContactPage} />
          <Route path="/login" exact component={Login} />
        </Switch>
      </Router>
    );
  }
  return (
    <div className="App">
      <AuthContext.Provider
        value={{
          isLoggedIn: !!token,
          userId: userId,
          token: token,
          login: login,
          logout: logout,
        }}
      >
        {routes}
      </AuthContext.Provider>
    </div>
  );
};

export default AllRoute;
