import React from "react";

// components
import Navbar from "../../components/Navbar";
import SimpleSlider from "../../components/hero";
//import Features from "../../components/features";
import AboutSection3 from "../../components/about3";
import ServiceArea3 from "../../components/ServiceArea3";

import FooterSection from "../../components/Footer";

const Homepage3 = () => {
  return (
    <div>
      <Navbar />
      <SimpleSlider />
      <AboutSection3 />
      <ServiceArea3 />

      <FooterSection />
    </div>
  );
};

export default Homepage3;
