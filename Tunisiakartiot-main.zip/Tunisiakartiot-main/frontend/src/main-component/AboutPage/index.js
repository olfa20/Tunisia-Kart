import React from "react";

// components
import Navbar from "../../components/Navbar";
import Breadcumb from "../../components/breadcumb";
import AboutSection2 from "../../components/about2";
import Mission from "../../components/Mission";

import FooterSection from "../../components/Footer";

const Aboutpage = () => {
  return (
    <div>
      <Navbar />
      <Breadcumb bdtitle={"About Us"} bdsub={"About"} />

      <AboutSection2 />
      <Mission />

      <FooterSection />
    </div>
  );
};

export default Aboutpage;
